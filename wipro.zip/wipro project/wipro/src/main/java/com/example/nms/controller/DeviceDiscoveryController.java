package com.example.nms.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.nms.serviceimpl.DeviceDiscoveryService;

@RestController
public class DeviceDiscoveryController {

	private final DeviceDiscoveryService deviceDiscoveryService;

	public DeviceDiscoveryController(DeviceDiscoveryService deviceDiscoveryService) {
		this.deviceDiscoveryService = deviceDiscoveryService;
	}

	@GetMapping("/discover")
	public String discoverDevice(@RequestParam String ipAddress) {
		deviceDiscoveryService.discoverDevice(ipAddress);
		return "Discovery initiated for IP: " + ipAddress;
	}
}
