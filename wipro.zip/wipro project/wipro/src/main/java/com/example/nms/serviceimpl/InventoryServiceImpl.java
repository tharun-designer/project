package com.example.nms.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.nms.discovery.SnmpDiscovery;
import com.example.nms.inventory.entity.Device;
import com.example.nms.inventory.repository.DeviceRepository;

@Service
public class InventoryServiceImpl implements InventoryService {

	@Autowired
	private DeviceRepository deviceRepo;

	@Autowired
	private SnmpDiscovery snmpDiscovery;

	@Override
	public Device addDevice(Device device) {
		return deviceRepo.save(device);
	}

	@Override
	public List<Device> viewAllDevices() {
		return deviceRepo.findAll();
	}

	@Override
	public Optional<Device> viewDeviceById(long id) {
		return deviceRepo.findById(id);
	}

	@Override
	public List<Device> viewAllConnectedDevices() {

		try {

			snmpDiscovery.getAllConnectedDevicesToMyNetwork();

		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	/*
	 * private List<Device> connectedDevicesInfo(){ return null; }
	 */

	/*
	 * @Override public void deleteDevice(Long id) {
	 * 
	 * deviceRepo.deleteById(id);
	 * 
	 * }
	 */

}
