package com.example.nms.serviceimpl;

import org.springframework.stereotype.Service;

import com.example.nms.discovery.SnmpDiscovery;

@Service
public class DeviceDiscoveryService {
	
	private final SnmpDiscovery snmpDiscovery;

    public DeviceDiscoveryService(SnmpDiscovery snmpDiscovery) {
        this.snmpDiscovery = snmpDiscovery;
    }

    public void discoverDevice(String ipAddress) {
        snmpDiscovery.discoverDevice(ipAddress);
    }

}
