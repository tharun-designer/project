package com.example.nms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproApplication {

	public static void main(String[] args) {
		SpringApplication.run(WiproApplication.class, args);
		
		System.out.println("TILL NOW CURD OPERATIONS DONE");
	}

}
